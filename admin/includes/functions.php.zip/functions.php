<?php
// function distributeMLMCommissions($pdo, $investment_id) {
//     // 1. Fetch investment and user path
//     $stmt = $pdo->prepare("SELECT i.amount, u.path, u.username FROM investments i JOIN users u ON i.user_id = u.id WHERE i.id = ?");
//     $stmt->execute([$investment_id]);
//     $inv = $stmt->fetch();
    
//     if (!$inv || empty($inv['path'])) return;

//     // 2. Fetch all 10-level commission settings
//     $settings_stmt = $pdo->query("SELECT level, commission_percent FROM mlm_settings ORDER BY level ASC");
//     $mlm_rates = $settings_stmt->fetchAll(PDO::FETCH_KEY_PAIR);

//     // 3. Convert path string to array and reverse it (closest upline is Level 1)
//     $upline_ids = array_reverse(explode('/', $inv['path']));

//     foreach ($upline_ids as $index => $upline_id) {
//         $level = $index + 1;
//         if ($level > 10) break; // Limit to 10 levels

//         if (isset($mlm_rates[$level])) {
//             $percentage = $mlm_rates[$level];
//             $bonus_amount = ($inv['amount'] * $percentage) / 100;

//             // 4. Credit the upline wallet
//             $update = $pdo->prepare("UPDATE users SET wallet_balance = wallet_balance + ? WHERE id = ?");
//             $update->execute([$bonus_amount, $upline_id]);

//             // 5. Generate Transaction History
//             $log = $pdo->prepare("INSERT INTO transactions (user_id, amount, type, description) VALUES (?, ?, 'referral_bonus', ?)");
//             $desc = "Level $level Referral Bonus from " . $inv['username'];
//             $log->execute([$upline_id, $bonus_amount, $desc]);
//         }
//     }
// }


function distributeMLMCommissions($pdo, $investment_id) {

    /* ===============================
       FETCH INVESTMENT + USER DATA
    ================================= */

    $stmt = $pdo->prepare("
        SELECT 
            i.amount,
            i.hash_ref,
            s.name AS scheme_name,
            s.type AS scheme_type,
            u.path,
            u.username
        FROM investments i
        JOIN users u ON i.user_id = u.id
        JOIN investment_schemes s ON i.scheme_id = s.id
        WHERE i.id = ?
    ");

    $stmt->execute([$investment_id]);
    $inv = $stmt->fetch();

    if (!$inv || empty($inv['path'])) return;

    /* ===============================
       DETECT CORPORATE / ADMIN
    ================================= */

    $is_corporate =
        stripos($inv['scheme_name'], 'corporate') !== false ||
        $inv['scheme_type'] === 'corporate';

    $is_admin_assigned =
    stripos($inv['hash_ref'], 'COMPANY') !== false ||
    stripos($inv['hash_ref'], 'ADMIN_ASSIGNED') !== false;

    /* Skip commissions if invalid */
    if ($is_corporate || $is_admin_assigned) {
        return;
    }

    /* ===============================
       FETCH MLM SETTINGS
    ================================= */

    $settings_stmt = $pdo->query("
        SELECT level, commission_percent 
        FROM mlm_settings 
        ORDER BY level ASC
    ");

    $mlm_rates = $settings_stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    /* ===============================
       PREPARE UPLINE LIST
    ================================= */

    $path = str_replace(',', '/', $inv['path']);
    $upline_ids = array_reverse(explode('/', $path));

    foreach ($upline_ids as $index => $upline_id) {

        $upline_id = (int)$upline_id;
        if ($upline_id <= 0) continue;

        $level = $index + 1;
        if ($level > 10) break;

        if (!isset($mlm_rates[$level])) continue;

        $percentage = $mlm_rates[$level];
        $bonus_amount = round(($inv['amount'] * $percentage) / 100, 8);

        if ($bonus_amount <= 0) continue;

        /* ===============================
           DUPLICATE PROTECTION
        ================================= */

        $check = $pdo->prepare("
            SELECT id 
            FROM transactions
            WHERE user_id = ?
            AND investment_id = ?
            AND type = 'referral_bonus'
            AND description LIKE ?
            LIMIT 1
        ");

        $check->execute([
            $upline_id,
            $investment_id,
            "%Level $level%"
        ]);

        if ($check->fetch()) {
            continue;
        }

        /* ===============================
           CREDIT WALLET
        ================================= */

        $pdo->prepare("
            UPDATE users
            SET wallet_balance = wallet_balance + ?
            WHERE id = ?
        ")->execute([$bonus_amount, $upline_id]);

        /* ===============================
           TRANSACTION RECORD
        ================================= */

        $desc = "Level $level Referral Bonus from {$inv['username']} (Inv #{$investment_id})";

        $pdo->prepare("
            INSERT INTO transactions
            (user_id, investment_id, amount, type, description, created_at)
            VALUES (?, ?, ?, 'referral_bonus', ?, NOW())
        ")->execute([
            $upline_id,
            $investment_id,
            $bonus_amount,
            $desc
        ]);
    }
}